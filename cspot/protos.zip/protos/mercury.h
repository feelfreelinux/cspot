// THIS CORNFILE IS GENERATED. DO NOT EDIT! 🌽
#ifndef _MERCURYH
#define _MERCURYH
#include <optional>
class Header {
public:
std::optional<std::string> uri;
std::optional<std::string> method;
static constexpr ReflectTypeID _TYPE_ID = ReflectTypeID::ClassHeader;
};

#endif
